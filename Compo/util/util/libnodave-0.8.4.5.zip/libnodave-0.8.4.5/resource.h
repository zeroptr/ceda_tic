//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FDLDemo.rc
//
#define IDD_ERROR                       101
#define IDD_DATA                        102
#define IDM_START                       200
#define IDC_ERRMSG                      1001
#define IDC_ERRNB                       1002
#define IDC_RECEIVED_DATA               1003
#define IDC_SENT_DATA                   1004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         201
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
