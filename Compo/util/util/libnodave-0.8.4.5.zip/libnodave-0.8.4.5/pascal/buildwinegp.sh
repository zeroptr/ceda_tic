#
# compile with Freepascal, GNU pascal compatibiliy mode.
#
wine c:/pp/bin/win32/fpc -B -Sp testPPI.pas
wine c:/pp/bin/win32/fpc -B -Sp testMPI.pas
wine c:/pp/bin/win32/fpc -B -Sp testISO_TCP.pas
wine c:/pp/bin/win32/fpc -B -Sp testIBH.pas
wine c:/pp/bin/win32/fpc -B -Sp testPPI_IBH.pas
