wine c:/pp/bin/win32/fpc $1 -B testPPI.pas
wine c:/pp/bin/win32/fpc $1 -B testMPI.pas
wine c:/pp/bin/win32/fpc $1 -B testISO_TCP.pas
wine c:/pp/bin/win32/fpc $1 -B testIBH.pas
wine c:/pp/bin/win32/fpc $1 -B testPPI_IBH.pas
