/*==============================================================*/
/* Database name:  MySql                                        */
/* DBMS name:      MySQL 3.23                                   */
/* Created on:     04.02.2003 19:48:39                          */
/*==============================================================*/

drop table table735226a;
drop table table735226b;
drop table Table726788;
drop table table735299;
drop table table740899;
drop table table724542;
drop table table739448a;
drop table table739448b;
drop table table733236;
drop table table768163;
drop table table799863;
drop table table000001;
drop table table817607;
drop table table816925;
drop table table828147;
drop table table840608;
drop table table849723;
drop table table869609;
drop table table865564;
drop table table881634a;
drop table table881634b;
drop table table884135a;
drop table table884135b;
drop table table886841;
drop table table894367a;
drop table table894367b;
drop table table894367c;
/*
drop table table914436;
*/
drop table `Table 938705`;
drop table table957126;
drop table table987022;
drop table table989474;
drop table table1045286;
