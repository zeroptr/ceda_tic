/*==============================================================*/
/* Database name:  MySql                                        */
/* DBMS name:      MySQL 3.23                                   */
/* Created on:     04.02.2003 19:48:39                          */
/*==============================================================*/

drop table blob_values;
drop table date_values;
drop table default_values;
drop table department;
drop table equipment;
drop table equipment2;
drop table extension;
drop table number_values;
drop table people;
drop table string_values;
drop table cargo;
drop table high_load;
