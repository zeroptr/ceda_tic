//---------------------------------------------------------------------------

#include <vcl.h>
#include <TextTestRunner.hpp>
#pragma hdrstop

//---------------------------------------------------------------------------

#pragma argsused
int main(int argc, char* argv[])
{
  Texttestrunner::RunRegisteredTests(rxbContinue);
  return 0;
}
//---------------------------------------------------------------------------
 