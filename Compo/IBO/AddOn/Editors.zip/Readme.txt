{===========================================================}
{= Property Editors for TIB_Query                          =}
{= Version: 1.0                                            =}
{=                                                         =}
{= Walter Campelo                                          =}
{= WEA Sistemas de Informatica                             =}
{= e-mail adress: weasistemas@netsite.com.br               =}
{=                                                         =}
{= Editors for properties:                                 =}
{= OrderingItems                                           =}
{= OrderingLinks                                           =}
{=                                                         =}
{= Instalation:                                            =}
{= Delphi 3:                                               =}
{=   Open IBO_EditorsPackD3.dpk in the IDE and install it. =}
{= Delphi 5:                                               =}
{=   Open IBO_EditorsPack.dpk in the IDE and install it    =}
{=                                                         =}
{= This property editors was only tested with D5, but they =}
{= should work with D3 as well.                            =}
{=                                                         =}
{===========================================================}

