IB_DataSetPageProducer
Version 0.2
(c) 2001 Nando Dessena

DISCLAIMER AND LICENSE

This component is distributed as freeware. It is provided 'as is' with no guarantees whatsoever. Use it at your own risk in every way you may find appropriate. Credits will be appreciated.

INTRODUCTION

This component works like a TDataSetPageProducer, except that it's linked to a native TIB_Dataset rather than a TDataSet. It also has some facilities to output multiple records and link to other producers (for master-detail HTML reports, etc.). It is at a very early stage since it does exactly what I need now and nothing more. It is actually a few simple lines of code, for now. Features will be added as suggested or as the need arises. Suggestions and contributes are also welcome.

SYSTEM REQUIREMENTS

This component has been tested under Delphi 5 Enterprise only; chances are it will work with any version of Delphi, C++ Builder or Kylix that supports WebBroker and IBO.

INSTALLATION

Compile IB_ProdD5.dpk first, putting the resulting bpl and dcp files in a suitable directory of the system and Delphi path, then compile and install dclIB_ProdD5.dpk.

USE

Please refer to the Delphi help file for TDataSetPageProducer and to the comments in the source code for use.
The component has two extra properties that TDataSetPageProducer doesn't feature:

MaxRows can be used to produce multirecord pages. The content of HTMLDoc or HTMLFile will be concatenated and transformed once for each record. Use -1 to indicate that the whole dataset must be produced.

Options is a collection of flags (just one, for now):
dpFromBeginning tells the component to start from the beginning of the dataset instead of the current record.

Another difference is that it will prepare and open the linked dataset if necessary, and will try to leave it in the same state it was found once finished.
