ConsoleTXTExport 
----------------
is an app to export an IB query to a delimited text file (with corresponding schema file).
Can be used from a DOS prompt as stated when invoked with wrong parameters number:

C:\>consoletxtexport
Usage: <this exe exename> verboselevel dbpath usr passwd queryfile resultfile
verboselevel is {0|1|2} (silent|normal|debug)
Exampli gratia:
C:\ConsoleTXTExport.exe 2 mydb.gdb sysdba masterkey query.sql result.txt
C:\>

(I put <this exe exename> in place of the current exe name, thinking in users who renames the large exe name...)

If an error occurs, the exit ERRORLEVEL is set to some number in order to do (in a .bat):
if ERRORLEVEL 1 goto wrong

See the example file "bat.bat", wich uses "query.sql" and "result.txt" and "result.schema".
(you must change the isc4.gdb path if want to execute bat.bat, and, please, set a large DOS window). 
Try to change some parameters and see how this affects the console output, and the echo WRONG or OK from the batch execution.


(is a very simple app when based in the excellent IBObjects component IBExport from the excellent IBObjects components set from James Wharton.)

Author

Adri�n Allende 
28/3/2000
