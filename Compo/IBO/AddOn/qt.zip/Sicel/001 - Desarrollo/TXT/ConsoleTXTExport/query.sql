
select * 
from users ;
