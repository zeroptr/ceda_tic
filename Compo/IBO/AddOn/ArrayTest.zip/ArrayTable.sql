Connect "server:d:\ibdata\TestDB.gdb" USER SYSDBA PASSWORD xxxxxx ;

create table ArrayTable(
             ID integer,
             Updated date,
             Prices double precision[196,14],
             Costs double precision[196,12],
             Attrib char(10)[196,7]
             );

grant all on ArrayTable to PUBLIC;


