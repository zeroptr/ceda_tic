CREATE DATABASE "photo.gdb" USER "sysdba" PASSWORD "masterkey";

CREATE GENERATOR photo_gen;

CREATE TABLE photo (
	id		INTEGER NOT NULL,
	description	BLOB SUB_TYPE TEXT SEGMENT SIZE 80,
	picture		BLOB SUB_TYPE 0 SEGMENT SIZE 4096,
	day		DATE,
	PRIMARY KEY	(id)
);


SET TERM !! ;

CREATE TRIGGER photo_insert FOR photo
 BEFORE INSERT AS
BEGIN
  IF (NEW.id IS NULL) THEN NEW.id = GEN_ID(photo_gen,1);
  IF (NEW.day IS NULL) THEN NEW.day = 'TODAY';
END !!

SET TERM ; !!


COMMIT;
EXIT;

