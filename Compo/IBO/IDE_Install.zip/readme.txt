Extra files for installing IBO4 help into Delphi OpenHelp system
================================================================
In this kit are files you can use to install the IBO40.hlp file
into the Delphi OpenHelp system manually.  This is recommended
if the OpenHelp wizard fails to install it correctly for you.

� The files starting with "edit_" contain marked passages for you
  to copy and paste into the corresponding file in ($DELPHI)/Help.
  For example, edit_delphi6.ohx contains a marked snippet for you
  to copy and paste into delphi6.ohx (or delphi5.ohx, if appropri-
  ate).

� IBO40.cnt is *different* to the IBO40.cnt that is in the main
  helpfile download.  Overwriting that file with the one here
  will make the original Contents file no longer usable if you
  wish to invoke IBO40.hlp "stand-alone".

� You will need to add the files IBO40.toc and IBO40.als to your
  Delphi Help directory, along with the helpfile itself and the
  edited delphi6.oh* files.  Note:  prior to Delphi 6, OpenHelp
  can not use the .als file, which stores all of the "See also"
  style of links.

When you have done all of this, you are ready to have OpenHelp 
incorporate the IBO40 helpfile into the IDE help system.

Now, do as follows:

1.  Close Delphi.
2.  Go to the Delphi help directory and delete the file delph6.GID
3.  Start up Delphi.
4.  Invoke the help in any way you like.  A message will appear 
    saying "Preparing help files for first use..." (this means it 
    is building a new delphi6.GID file)

Now, the IBO 4 help is fully integrated into the IDE help.

Context-sensitive help - possible bug observed in Delphi 6
==========================================================
..and a workaround of sorts..

If you place the edit cursor on a symbol in the Delphi editor or
in the Object Inspector, then press F1, the OpenHelp engine should
take you to the corresponding help topic.  In many installations,
this seems to work properly only for components and members that
are documented in the "core" Borland help files.

In the case of third-party help files, the context-sensitive help
facility seems to work only if there are >> no help files open <<
in the IDE at the time you press F1.

This means context-sensitive help for third-party components is 
quite crippled for the time being (at Upgrade 2, time of writing).
However, the Contents and Index searches work well.  For most
users, it will be faster to use the Index, especially now that the
IBO code is fully indexed and inherits topic content from ancestor
classes.

We're very keen to hear from anyone who finds a proper solution to
this bug;  or who knows of a resource on-line that would help us
to fix it at source level.  Please email your suggestions to

Helen Borrie <hborrie@ibobjects.com>

Thanks!  enjoy!
 